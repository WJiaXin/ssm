create
    definer = root@localhost procedure `3`()
BEGIN
    DECLARE num INT ;
    SET num = 1 ;
    WHILE num <= 80 DO
    INSERT INTO 报名信息 (BM_NUM,BM_PC,BM_ZT,BM_ID,BM_TIME,BM_XH)
    VALUES (num,'1','0',num,'2020-04-221',BM_NUM+BM_TIME);
    SET  num=num+1;

    END WHILE ;
END;

